
<?php
 require_once "Connect.php";
 require_once "templete.php";
 $sql="SELECT * FROM Employe  ";
  
 $stmt= $db->query($sql);

 


 
if (isset($_POST['enregistrer'])) {

    
    $id= $_POST['id_employe'];
    $service= $_POST['nom_employe'];
    $prenom = $_POST['prenom_employe'];
    $maticule = $_POST['matricule_employe'];
    $poste = $_POST['poste'];
    $sql = null;
if (isset($_POST['id_employe']) && isset($_POST['nom_employe'])&& isset($_POST['matricule_employe'])&& isset($_POST['poste'])) {
        $sql = " UPDATE  Employe set nom_employe='".$service."'  where  (id_employe ='".$id."') "; 
        
        // utilise exec() car aucun résultat n'est renvoyé
        $db->exec($sql);
        //creation de l'enregistrement
        echo " Nouvel enregistrement crée avec success ";
    } else {
        echo " Nouvel enregistrement refusé   ";
        
    }
    
    }


    $sql="SELECT * FROM Employe ";
  
    $stmt= $db->query($sql);
       
       
     if(isset($_GET['id_employe']))
        {
            $id = $_GET['id_employe'];
            $req = " delete from Employe where (id_employe ='".$id."')";
            $db->exec($req);
        
        
        }
        
    

 ?>



<div id="page-wrapper" style="min-height: 292px;">

    <div class="row">
        <div class="col-lg-12">
            <div class="panel panel-default">
                <div class="panel-heading">
                    Liste des employés
                </div>
                <!-- /.panel-heading -->
                <div class="panel-body">
                    <div class="dataTable_wrapper">
                        <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                            <thead>
                            <tr>
                               
                                <th  class=" col-sm-1 ">NOM EMPLOYE</th>
                                <th class=" col-sm-1">PRENOM</th>
                                <th class=" col-sm-1 ">MATRICULE</th>
                                <th class=" col-sm-1 ">POSTE</th>
                                <th class=" col-sm-1 ">NOM SERVICE</th>
                                <th class=" col-sm-1 ">MATRICULE TELEPHONE</th>

                                <th class=" col-sm-3 ">Action</th>
                            </tr>
                            </thead>
                            <?php while($row = $stmt->fetch(PDO::FETCH_ASSOC)) : ?>
                            <tbody>

                            <tr>
                            
                            <td> 
                            <?php echo $row['nom_employe']; ?>  
                            </td>
                            <td>
                            <?php echo $row['prenom_employe']; ?>  
                            </td>
                            <td>
                            <?php echo $row['matricule_employe']; ?>  
                            </td>
                            <td>
                            <?php echo $row['poste']; ?>  
                            </td>
                            <td>
                            <?php
                             $nbr3 = $row['id_services'];
                             $sql8="SELECT * FROM `Services`  where `id_services`='$nbr3'";
                             $stmt4= $db->query($sql8);
                             $row4 = $stmt4->fetch(PDO::FETCH_ASSOC);
                             echo $row4['nom_services']; ?>  
                            </td>
                            <td>
                            
                            <?php 
                              $nbr = $row['id_telephone'];
                              $sql2="SELECT * FROM `Telephone`  where `id_telephone`='$nbr'";
                              $stmt2= $db->query($sql2);
                              $row2 = $stmt2->fetch(PDO::FETCH_ASSOC);
                              echo $row2['matricule'];
                             ?>  
                            </td>
                                <td>
                                <a type="button" class="btn btn-warning" href="modifieremp.php?nom_employe=<?php echo $row['nom_employe'];?>&prenom_employe=<?php echo $row['prenom_employe']; ?>&matricule_employe= <?php echo $row['matricule_employe']; ?>&poste= <?php echo $row['poste']; ?> "><i class="fa fa-edit fa-lg"></i> Editer</a>
                                <a type="button" class="btn btn-danger" href="liste_employe.php?id_employe=<?php echo $row['id_employe'];?>"><i class="fa fa-trash fa-lg"></i> Supprimer</a>
                                </td>
                            </tr>
                            <?php endwhile; ?>
                            </tbody>

                        </table>
                    </div>
                    <!-- /.panel-body -->
                </div>
                <!-- /.panel -->
            </div>
            <!-- /.col-lg-12 -->
        </div>
        <!-- /.row -->
