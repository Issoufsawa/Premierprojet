<?php
//on verifie si le formulaire a été envoyé 

if (!empty($_POST)){

    // Le formulaire a été envoyé 
    // on vérifie que tous les champs requis son remplis
  if(isset($_POST["email"], $_POST["passwords"]) && !empty($_POST["email"]) && !empty( $_POST["passwords"]) ){

 // le formulaire est complet 
 // on récupère les données en les protégeant
    if(!filter_var($_POST["email"] , FILTER_VALIDATE_EMAIL)){
        die("L'adresse email est incomplet");
    }
 
    // on va hasher le mot de passe
    $pass = password_hash($_POST["passwords"], PASSWORD_ARGON2ID);
    
    // On enregistre en bdd

    

}else{
     die("Le formulaire est incomplet");
   }
}


?>