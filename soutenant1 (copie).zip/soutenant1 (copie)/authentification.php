<!DOCTYPE html>
<html>

<head>
    <link href="font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <meta charset="utf-8">

    <title>AUTHENTIFICATION</title>
</head>








<div id="page-wrapper" style="min-height: 292px;">




    <div class="row">
        <div class="col-lg-12 col-md-12">
            <h3 align="center" class=" bg-success titre-contact"> SE CONNECTER </h3>

            <div class="panel panel-primary">
                <form class="form-horizontal" data-toggle="validator" role="form" method="post">
                    <p></p>
                    <div class="row">
                        <div class="col-xs-12">

                            <!--<form class="form-horizontal" role="form">-->

                            <div class="form-group">
                                <label class=" col-sm-4 control-label">EMAIL :</label>
                                <div class="col-sm-6">
                                    <input type="email" class="form-control" name="email" id="email" required>
                                </div>
                            </div>

                            <div class="form-group">
                                <label class=" col-sm-4 control-label">PASSWORD :</label>
                                <div class="col-sm-6">
                                    <input type="password" class="form-control" name="passwords" id="passwords" required>
                                </div>
                            </div>
                            <div class="form-group">

                                <div class="col-sm-4">
                                    <p>
                                        <button type="submit" class="btn btn-primary" name="enregistrer">CONNEXION </button>
                                    </p>
                                </div>
                            </div>








                        </div>
                        <!--col-xs-12 -->

                    </div>
                    <!--row -->

                </form> <!--  /form>-->



            </div>

        </div>

</html>
<?php
require_once "Connect.php";

if (isset($_POST['enregistrer'])) {

    $email = $_POST['email'];
    $passwords = $_POST['passwords'];
    $password = hash('sha256', $passwords);
    $sql = "SELECT * FROM user WHERE email ='$email' AND passwords ='$password' ";
    $stmt = $db->prepare($sql);
    $stmt->execute();
    $result = $stmt->fetch(PDO::FETCH_BOTH);
       
   // print_r($result['type_user']);
  // var_dump(hash('sha256', $passwords ));  
  // var_dump(hash('sha256', $passwords));
    if ($stmt->rowCount() > 0) {


        //$result = $stmt->fetch(PDO::FETCH_BOTH);
       
        if ($result['type_user'] == 0) {
            
            header("location: templeteadmin.php");
        } else {

            header("location: templete.php");
        }
    } else {

        echo "Incorrect";
    }
}



?>