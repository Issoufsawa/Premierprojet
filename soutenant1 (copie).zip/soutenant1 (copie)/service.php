<?php
require_once "Connect.php";
 require_once "templete.php" ;
?>
<div id="page-wrapper" style="min-height: 292px;">

       <div class="row">
        <div class="col-lg-12 col-md-12">
            <h3 align = "center" class=" bg-success titre-contact">  AJOUTER UN SERVICE </h3>

            <div class="panel panel-primary">
                <form class="form-horizontal" data-toggle="validator"  role="form"  method="post" >
                    <p></p>
                    <div class="row">
                        <div class="col-xs-12">
                            <div class="col-xs-5">
                                <!--<form class="form-horizontal" role="form">-->
                             </div><!--  col-xs-5-->

                            <div class="col-xs-5">
                                  <div class="form-group">
                                    <label  class=" col-sm-4 control-label">NOM SERVICE:</label>
                                    <div class="col-sm-8">
                                        <input type="text" class="form-control" name="nom_services" id="nom_services" pattern="[a-zA-Z]" required>
                                    </div>
                                </div>
                                
                         <div class="form-group">
                                   
                             <div class="col-sm-8">

                                       

                                  </div>
                                </div>
                                     
                                
                               
                                </div><!--  /col-xs-5>-->
                        <div class="col-xs-2">
                            <p>
                              <button type="submit" class="btn btn-primary" name="enregistrer">Valider </button>
                            </p>
                            
                        </div> <!--col-xs-2 -->
                        </div> <!--col-xs-12 -->
            
                    </div> <!--row -->

                </form> <!--  /form>-->



            </div>

        </div>



    <?php


$sql = null;
if (isset($_POST['enregistrer'])) {
   
   
    if (isset($_POST['nom_services'])&& !empty($_POST['nom_services'])){
          
    
     $service=$_POST['nom_services'];
     
     $sql = " INSERT INTO Services (nom_services) 
        VALUES ('$service') ";
                // utilise exec() car aucun résultat n'est renvoyé
        $db->exec($sql);
//         //creation de l'enregistrement
       echo " Nouvel enregistrement crée avec success ";
     } else {
        echo " nom de service vide  ";
        
    }
}
