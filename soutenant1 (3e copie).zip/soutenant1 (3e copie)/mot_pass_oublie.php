<?php
 require_once "templete.php"


 ?>




<div id="page-wrapper" style="min-height: 292px;">

       <div class="row">
        <div class="col-lg-12 col-md-12">
            <h3 align = "center" class=" bg-success titre-contact"> CONSOMMATION </h3>

            <div class="panel panel-primary">
                <form class="form-horizontal" data-toggle="validator"  role="form"  method="post" >
                    <p></p>
                    <div class="row">
                        <div class="col-xs-12">
                            <div class="col-xs-5">
                                <!--<form class="form-horizontal" role="form">-->

                                <div class="form-group">
                                    <label  class=" col-sm-6 control-label">NOUVEAU MOT DE PASS :</label>
                                    <div class="col-sm-6">
                                        <input type="password" class="form-control" name="password" id="password">
                                    </div>
                                </div>

                                
                            
                                
                            </div><!--  col-xs-5-->

                            <div class="col-xs-5">

                                
                                    
                                <div class="form-group">
                                    <label  class=" col-sm-4 control-label">CONFIRMER MOT DE PASS</label>
                                    <div class="col-sm-8">
                                        <input type="password" class="form-control" name="confi_password" id="confi_passord">
                                    </div>
                                </div>
                                
                                      <div class="form-group">
                                   
                                    <div class="col-sm-8">

                                       

                                  </div>
                                </div>
                                     
                                
                               
                                </div><!--  /col-xs-5>-->
                        <div class="col-xs-2">
                            <p>
                              <button type="submit" class="btn btn-primary" name="enregistrer">Valider </button>
                            </p>
                            
                        </div> <!--col-xs-2 -->
                        </div> <!--col-xs-12 -->
            
                    </div> <!--row -->

                </form> <!--  /form>-->



            </div>

        </div>
