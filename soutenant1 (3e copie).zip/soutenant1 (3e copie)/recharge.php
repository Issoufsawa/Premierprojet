

<?php
 require_once "templete.php";

 require_once "Connect.php";




$sql1="SELECT * FROM carte_sim ";
  
$stmt1= $db->query($sql1);


 ?>




<div id="page-wrapper" style="min-height: 292px;">

       <div class="row">
        <div class="col-lg-12 col-md-12">
            <h3 align = "center" class=" bg-success titre-contact">  AJOUTER UNE RECHARGE</h3>

            <div class="panel panel-primary">
                <form class="form-horizontal" data-toggle="validator"  role="form"  method="post" >
                    <p></p>
                    <div class="row">
                        <div class="col-xs-12">
                            <div class="col-xs-5">
                                <!--<form class="form-horizontal" role="form">-->

                               

                                <div class="form-group">
                                   <label  class=" col-sm-4 control-label">CARTE SIM:</label>
                                    <div class="col-sm-6">
                                    <select name="id_carte_sim" class="form-control" required >



                                    /* affiche les id des cartes sim et les numero correspondes *\
                                        <?php while($row = $stmt1->fetch(PDO::FETCH_ASSOC)) : ?>
                                
                                <option value="<?php echo $row['id_carte_sim']; ?>"><?php echo $row['numero_sim']; ?></option>
                                
                                
                                
                                
         
                            <?php endwhile; ?>
                                          
                                        </select>
                                        
                                    </div>
                                </div>
                            
                                <div class="form-group">
                                    <label  class=" col-sm-4 control-label">DATA:</label>
                                    <div class="col-sm-8">
                                        <input type="tel" class="form-control" name="rdata" id="rdata" pattern="[-+]?[0-9]+(\.[0-9]+)?([eE][-+]?[0-9]+)?" title=" exemple de format 55 ou 55.5" required> 
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label  class=" col-sm-4 control-label">SMS:</label>
                                    <div class="col-sm-8">
                                        <input type="text" class="form-control" name="rsms" id="rsms"  pattern="[0-9]+" title=" exemple de format 55 ou 55.5"  required>
                                    </div>
                                </div>

                            </div><!--  col-xs-5-->
                            

                            <div class="col-xs-5">

                                
                                    
                            
                                
                                      <div class="form-group">
                                    <label  class=" col-sm-4 control-label">MINUTE:</label>
                                    <div class="col-sm-8">

                                        <input type="text" class="form-control" name="rminute" id="rminute"  pattern="[-+]?[0-9]+(\.[0-9]+)?([eE][-+]?[0-9]+)?"  title="exemple de farmat 55 ou 55.5 "required>

                                  </div>
                                </div>
                                      <div class="form-group">
                                 <label  class=" col-sm-4 control-label">DATE D'EXIPARATION:</label>
                                    <div class="col-sm-8">
                                    
                                   
                                    <input type="date" class="form-control" name="date_dexpi" id="date_dexpi" required>
 
                                  </div>
                                </div>
                                
                                <div class="form-group">
                                    <label  class=" col-sm-4 control-label">CREDIT:</label>
                                    <div class="col-sm-8">
                                    <input type="text" class="form-control" name="rcredit" id="rcredit"  pattern="[0-9]+" title=" exemple de format 550"  required>
                                    </div>
                                </div>
                                </div><!--  /col-xs-5>-->
                        <div class="col-xs-2">
                            <p>
                              <button type="submit" class="btn btn-primary" name="enregistrer">Valider </button>
                            </p>
                            
                        </div> <!--col-xs-2 -->
                        </div> <!--col-xs-12 -->
            
                    </div> <!--row -->

                </form> <!--  /form>-->



            </div>

        </div>



<?php
$sql = null;
if (isset($_POST['enregistrer'])) {

    $id_carte_sim = $_POST['id_carte_sim'];
    $credit= $_POST['rcredit'];
    $data = $_POST['rdata'];
    $sms = $_POST['rsms'];
    $minute = $_POST['rminute'];
    $datedexpi = $_POST['date_dexpi'];
    





if (isset($_POST['rcredit']) && isset($_POST['rdata']) 
    && isset($_POST['rsms']) && isset($_POST['rminute']) && isset($_POST['date_dexpi'])) {
        $sql = " INSERT INTO Recharge (id_carte_sim,rcredit,rdata,rsms,rminute,date_dexpi)  
        VALUES ('$id_carte_sim','$credit','$data','$sms','$minute','$datedexpi') ";
        // utilise exec() car aucun résultat n'est renvoyé
        $db->exec($sql);
        //creation de l'enregistrement
        echo " Nouvel enregistrement crée avec success ";
    } else {
        echo " Nouvel enregistrement refusé   <br>";
        
    }
}

