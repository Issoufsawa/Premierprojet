<?php
 require_once "Connect.php";
 require_once "templeteadmin.php";

 ?>

<div id="page-wrapper" style="min-height: 292px;">

       <div class="row">
        <div class="col-lg-12 col-md-12">
            <h3 align = "center" class=" bg-success titre-contact">  MODIFIER UN UTILISATEUR</h3>

            <div class="panel panel-primary">
                <form class="form-horizontal" data-toggle="validator"  role="form"  method="post" >
                    <p></p>
                    <div class="row">
                        <div class="col-xs-12">
                            <div class="col-xs-5">
                                <!--<form class="form-horizontal" role="form">-->

                                <div class="form-group">
                                    <label  class=" col-sm-4 control-label">EMAIL:</label>
                                    <div class="col-sm-8">
                                        <input type="email" class="form-control" name="email" id="email" value="<?php echo $_GET['email']  ?>"
                                               required>
                                    </div>
                                   
                                </div>

                             </div><!--  col-xs-5-->

                            <div class="col-xs-5">

                          <div class="form-group">
                                    <label  class=" col-sm-4 control-label">PASSSWORD:</label>
                                    <div class="col-sm-8">
                                        <input type="password" class="form-control" name="passwords" id="passwords" value="<?php echo $_GET['passwords']  ?>" required>
                                    </div>
                                </div>
                                
                                      <div class="form-group">
                                   
                                    <div class="col-sm-8">

                                       

                                  </div>
                                </div>
                                     
                                
                               
                                </div><!--  /col-xs-5>-->
                        <div class="col-xs-2">
                            <p>
                              <button type="submit" class="btn btn-primary" name="submit">Valider </button>
                            </p>
                            
                        </div> <!--col-xs-2 -->
                        </div> <!--col-xs-12 -->
            
                    </div> <!--row -->

                </form> <!--  /form>-->



            </div>

        </div>
 


<?php

if (isset($_POST['submit'])) {

    $id= $_GET['id_user'];
    $email= $_POST['email'];
    $password= $_POST['passwords'];


    $sql1 = null;
    if (isset($_POST['email']) && isset($_POST['passwords']) ) {
        $sql1 = " UPDATE User set email='".$email."', passwords='".$password."'  where (id_user='".$id."') ";
        // utilise exec() car aucun résultat n'est renvoyé
        $db->exec($sql1);
        //creation de l'enregistrement
        echo " modifiés avec success <br>";
    } else {
        echo " modification refusé   <br>";
        
    }
}

