<!DOCTYPE html>
<html>

<head>
    <link href="font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <meta charset="utf-8">

    <title>ACCUIEL</title>
</head>

<body>


    <div id="wrapper">

        <!-- Navigation -->
        <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">

            <div class="navbar-header">
                <span class="navbar-brand navbar-header"> Gestion admin - Gestion Telecom </span>
            </div>

        </nav>
        <!-- Menu vertical-->
        <! -- Menu vertical --->
            <div class="nav-side-menu">
                <div class="brand">Menu Principal </div>
                <i class="fa fa-bars fa-2x toggle-btn" data-toggle="collapse" data-target="#menu-content"></i>

                <div class="menu-list">

                    <ul id="menu-content" class="menu-content collapse out">
                        <!--Menu acceuil-->
                        <li data-toggle="collapse" data-target="#acceuil" class="collapsed active">
                            <a href="#"><i class="fa fa-home"></i> Acceuil<span class="arrow"></span></a>
                        </li>
                        <!--Menu SERVICE-->
                        <li data-toggle="collapse" data-target="#class" class="collapsed ">
                            <a href="#"><i class="fa fa-group fa-lg"></i> Services<span class="arrow"></span></a>
                        </li>
                        <ul class="sub-menu collapse" id="class">
                            <li><a href="service.php">Ajouter un Service</a></li>
                            <li><a href="liste_service.php">Liste des services</a></li>
                        </ul>

                        <!--Menu TELEPHONE-->
                        <li data-toggle="collapse" data-target="#etudiant" class="collapsed ">
                            <a href="#"><i class="fa fa-bank fa-lg "></i> Telephone <span class="arrow"></span></a>
                        </li>
                        <ul class="sub-menu collapse" id="etudiant">
                            <li><a href="telephone.php">Ajouter un Telephone</a></li>

                            <li> <a href="liste_telephone.php">Liste des Telephones</a></li>
                        </ul>
                        
                         <!--Menu CARTE SIM-->
                         <li data-toggle="collapse" data-target="#para" class="collapsed">
                            <a href="#"><i class="fa fa-gears fa-lg"></i> Carte Sim <span class="arrow"></span></a>
                        </li>
                        <ul class="sub-menu collapse" id="para">

                            <li><a href="carte_sim.php">Ajouter une Carte Sim</a></li>
                            <li><a href="liste_carte_sim.php">Liste des cartes sim</a></li>
                        </ul>
                        <!--Menu EMPLOYE-->
                        <li data-toggle="collapse" data-target="#ue" class="collapsed">
                            <a href="#"><i class="fa fa- fa-male"></i> Employé<span class="arrow"></span></a>
                        </li>
                        <ul class="sub-menu collapse" id="ue">
                            <li><a href="employe.php">Ajouter un Employé</a></li>
                            <li><a href="liste_employe.php">Liste des employés</li>

                        </ul>
                         <!--Menu RECHARGE-->
                         <li data-toggle="collapse" data-target="#rech" class="collapsed">
                            <a href="#"><i class="fa fa-gears fa-lg"></i> Recharge <span class="arrow"></span></a>
                        </li>
                        <ul class="sub-menu collapse" id="rech">

                            <li><a href="recharge.php">Ajouter une Recharges</a></li>
                            <li><a href="liste_recharge.php">Liste des recharges</a></li>
                        </ul>




                        
                        <!--Menu SOLDE-->

                        <li data-toggle="collapse" data-target="#enseignant" class="collapsed">
                            <a href="#"><i class="fa fa-desktop fa-lg"></i> Solde<span class="arrow"></span></a>
                        </li>
                        <ul class="sub-menu collapse" id="enseignant">
                            <li><a href="solde.php">Ajouter un solde</a></li>
                            <li><a href="liste_solde.php">Liste des soldes</a></li>
                        </ul>
                       

                       




                    </ul>



                </div>
            </div> <!-- nav-side-menu -->



    </div> <!-- page-wrapper-->

    </div><!-- wrapper-->


    <script type="text/javascript" src="js/jquery.js"></script>
    <script type="text/javascript" src="js/bootstrap.js"></script>

</body>

</html>