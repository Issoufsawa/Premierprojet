
<?php
 require_once "Connect.php";
 require_once "templete.php";
 $sql="SELECT * FROM Recharge ";
  
 $stmt= $db->query($sql);

 
if (isset($_POST['enregistrer'])) {

    
    $id= $_POST['id_solde'];
    $service= $_POST['s_credit'];
    $prenom = $_POST['s_data'];
    $maticule = $_POST['s_sms'];
    $poste = $_POST['s_minute'];
    $poste = $_POST['date_dexpi'];
    $poste = $_POST['carte_sim'];
    $sql = null;
if (isset($_POST['id_solde']) && isset($_POST['s_credit'])&& isset($_POST['s_data'])&& isset($_POST['s_sms'])) {
        $sql = " UPDATE  Employe set nom_employe='".$service."'  where  (id_employe ='".$id."') "; 
        
        // utilise exec() car aucun résultat n'est renvoyé
        $db->exec($sql);
        //creation de l'enregistrement
        echo " Nouvel enregistrement crée avec success ";
    } else {
        echo " Nouvel enregistrement refusé   ";
        
    }
   
}
$sql="SELECT * FROM Recharge ";
  
$stmt= $db->query($sql);


 if(isset($_GET['id_recharge']))
    {
        $id = $_GET['id_recharge'];
        $req = " delete from Recharge where (id_recharge ='".$id."')";
        $db->exec($req);
    
    
    }
    

?>



<div id="page-wrapper" style="min-height: 292px;">

    <div class="row">
        <div class="col-lg-12">
            <div class="panel panel-default">
                <div class="panel-heading">
                    Liste des recharges
                </div>
                <!-- /.panel-heading -->
                <div class="panel-body">
                    <div class="dataTable_wrapper">
                        <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                            <thead>
                            <tr>
                                
                                <th  class=" col-sm-1 "> CREDIT</th>
                                <th class=" col-sm-1">DATA</th>
                                <th class=" col-sm-1 ">SMS</th>
                                <th class=" col-sm-1 ">MINUTE</th>
                                <th class=" col-sm-1 ">DATE D'EXPIRATION</th>
                                <th class=" col-sm-1 ">CARTE SIM</th>

                                <th class=" col-sm-3 ">Action</th>
                            </tr>
                            </thead>
                            <?php while($row = $stmt->fetch(PDO::FETCH_ASSOC)) : ?>
                            <tbody>

                            <tr>
                            
                            <td> 
                            <?php echo $row['rcredit']; ?>  
                            </td>
                            <td>
                            <?php echo $row['rdata']; ?>  
                            </td>
                            <td>
                            <?php echo $row['rsms']; ?>  
                            </td>
                            <td>
                            <?php echo $row['rminute']; ?>  
                            </td>
                            <td>
                            <?php echo $row['date_dexpi']; ?>  
                            </td>
                            <td>
                        <?php 
                            $nbr = $row['id_carte_sim'];
                            $sql2="SELECT * FROM `carte_sim`  where `id_carte_sim`='$nbr'";
                            $stmt2= $db->query($sql2);
                            $row2 = $stmt2->fetch(PDO::FETCH_ASSOC);
                            echo $row2['numero_sim'];
                        ?>  
                            </td>
                                <td>
                                <a type="button" class="btn btn-warning" href="modifierrecharge.php?id_recharge=<?php echo $row['id_recharge'];?>&rcredit=<?php echo $row['rcredit'];?>&rdata= <?php echo $row['rdata']; ?>&rsms=<?php echo $row['rsms']; ?>&rminute=<?php echo $row['rminute']; ?>&date_dexpi=<?php echo $row['date_dexpi']; ?>  "><i class="fa fa-edit fa-lg"></i> Editer</a>
                                <a type="button" class="btn btn-danger" href="liste_recharge.php?id_recharge=<?php echo $row['id_recharge'];?>"><i class="fa fa-trash fa-lg"></i> Supprimer</a>
                                </td>
                            </tr>
                            <?php endwhile; ?>
                            </tbody>

                        </table>
                    </div>
                    <!-- /.panel-body -->
                </div>
                <!-- /.panel -->
            </div>
            <!-- /.col-lg-12 -->
        </div>
        <!-- /.row -->
