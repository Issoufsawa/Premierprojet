

<?php
 require_once "templete.php";

 require_once "Connect.php";

 
 
 
 $sql="SELECT * FROM Services  ";
   
 $stmt= $db->query($sql);
 
 
 $sql1="SELECT * FROM Telephone ";
   
 $stmt1= $db->query($sql1);


 ?>




<div id="page-wrapper" style="min-height: 292px;">

       <div class="row">
        <div class="col-lg-12 col-md-12">
            <h3 align = "center" class=" bg-success titre-contact">  AJOUTER UN EMPLOYE </h3>

            <div class="panel panel-primary">
                <form class="form-horizontal" data-toggle="validator"  role="form"  method="post" >
                    <p></p>
                    <div class="row">
                        <div class="col-xs-12">
                            <div class="col-xs-5">
                                <!--<form class="form-horizontal" role="form">-->

                                

                                <div class="form-group">
                                    <label  class=" col-sm-4 control-label">NOM EMPLOYE:</label>
                                    <div class="col-sm-8">
                                        <input type="text" class="form-control" name="nom_employe" id="nom_employe" required>
                                    </div>
                                </div>
                            
                                <div class="form-group">
                                    <label  class=" col-sm-4 control-label">PRENOM EMPLOYE:</label>
                                    <div class="col-sm-8">
                                        <input type="text" class="form-control" name="prenom_employe" id="prenom_employe" required>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label  class=" col-sm-4 control-label">MATRICULE :</label>
                                    <div class="col-sm-8">
                                        <input type="text" class="form-control" name="matricule_employe" id="matricule_employe" required >
                                    </div>
                                </div>
                                

                            </div><!--  col-xs-5-->
                            

                            <div class="col-xs-5">

                                
                                    
                              
                                      <div class="form-group">
                                    <label  class=" col-sm-4 control-label">POSTE :</label>
                                    <div class="col-sm-8">

                                        <input type="text" class="form-control" name="poste" id="poste" required >

                                  </div>
                                </div>

                                <div class="form-group">
                                 <label  class=" col-sm-4 control-label">NOM SERVICE:</label>
                                    <div class="col-sm-8">
                                    <select name="id_services" class="form-control" > 
                                    <?php while($row = $stmt->fetch(PDO::FETCH_ASSOC)) : ?>
                                
                                <option value="<?php echo $row['id_services']; ?>"><?php echo $row['nom_services']; ?></option>
                                
                                 <?php endwhile; ?>
                                    
                                    
                                        
                                        
                                          </select>

                                       
                                  </div>
                                </div>
                                     
                                <div class="form-group">
                                    <label  class=" col-sm-4 control-label">MATRICULE TELEPHONE:</label>
                                    <div class="col-sm-6">
                                        <select name="id_telephone" class="form-control" >
                                        <?php while($row = $stmt1->fetch(PDO::FETCH_ASSOC)) : ?>
                                
                                <option value="<?php echo $row['id_telephone']; ?>"><?php echo $row['matricule']; ?></option>
                                
                                
                                
                                
        
                            <?php endwhile; ?>
                                          
                                        </select>
                                    </div>
                                </div>



                                
                                </div><!--  /col-xs-5>-->
                        <div class="col-xs-2">
                            <p>
                              <button type="submit" class="btn btn-primary" name="enregistrer">Valider </button>
                            </p>
                            
                        </div> <!--col-xs-2 -->
                        </div> <!--col-xs-12 -->
            
                    </div> <!--row -->

                </form> <!--  /form>-->



            </div>

        </div>

<?php
$sql = null;
if (isset($_POST['enregistrer'])) {

    
    $nom = $_POST['nom_employe'];
    $prenom = $_POST['prenom_employe'];
    $maticule = $_POST['matricule_employe'];
    $poste = $_POST['poste'];
    $id_services = $_POST['id_services'];
    $id_telephone = $_POST['id_telephone'];
    $id_carte_sim = $_POST['id_carte_sim'];
  
    
if ( isset($_POST['nom_employe']) && isset($_POST['prenom_employe']) 
     && isset($_POST['matricule_employe']) && isset($_POST['poste'])   && isset($_POST['id_services']) && isset($_POST['id_telephone'])
     ) {
 $sql = $db->prepare("SELECT matricule_employe  FROM Employe WHERE matricule_employe='$maticule'");
        $sql->execute();
        $result = $sql->rowCount();
        $sql4 = $db->prepare("SELECT id_telephone  FROM Employe WHERE id_telephone='$id_telephone'");
        $sql4->execute();
        $result2 = $sql4->rowCount();
        
        if ($result) {
            
            echo  " un employé a déja ce matricule  svp <br> ";
        } elseif($result2) {
            echo  " un employe a déja ce matricule telephone svp <br> ";
        }else{

        $sql = " INSERT INTO Employe ( nom_employe, prenom_employe, matricule_employe, poste,id_services,id_telephone) 
      VALUES ('$nom','$prenom','$maticule' ,'$poste' , '$id_services', '$id_telephone') ";
        // utilise exec() car aucun résultat n'est renvoyé
        $db->exec($sql);
        //echo $id_carte_sim,$id_services;
        //creation de l'enregistrement
        echo " Nouvel enregistrement crée avec success ";
}
     }
    }
