<?php
$servername = "127.0.0.1";
$dbname = "sot";
$username = "root";
$password = "";
$port =3306;
$sql = null;
$sql1 = null;
$sql2 = null;
try {
  $conn = new PDO("mysql:host=$servername;$dbname=$dbname;port=$port", $username, $password);
  // définit le mode d'erreur PDO sur exception
  $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
  $sql = "CREATE DATABASE sot";
  // utilise exec() car aucun résultat n'est renvoyé
  $conn->exec($sql);
  echo "Database created successfully<br>";
} catch (PDOException $e) {
  echo $sql . "<br>" . $e->getMessage();
}

$conn = null;

try {
  $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
  // set the PDO error mode to exception
  $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

  /** create the multiples tables **/

  $sql1 = [

    'CREATE TABLE Telephone (
      id_telephone INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
      marque VARCHAR(50),
      matricule VARCHAR (50),
      is_delete TINYINT(1),
      create_dat DATETIME,
      update_dat TIMESTAMP
    );',

    'CREATE TABLE Services (
      id_services INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
      nom_services VARCHAR(50),
      is_delete TINYINT(1),
      create_dat DATETIME,
      update_dat TIMESTAMP
      );',

    'CREATE TABLE Employe (
  id_employe INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  nom_employe VARCHAR(50),
  prenom_employe VARCHAR (50),
  matricule_employe VARCHAR (50),
  poste VARCHAR (50),
  is_delete TINYINT(1),
  create_dat DATETIME,
  update_dat TIMESTAMP,
  id_services INT(6) UNSIGNED,
   CONSTRAINT fk_Services
    FOREIGN KEY(id_services)
    REFERENCES Services(id_services) 
    ON DELETE CASCADE,
    id_telephone INT(6) UNSIGNED,
    CONSTRAINT fk_Telephone
    FOREIGN KEY( id_telephone) 
    REFERENCES Telephone( id_telephone) 
    ON DELETE CASCADE
   
  );',

    'CREATE TABLE carte_sim (
       id_carte_sim INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
       operateur VARCHAR (50),
       numero_sim VARCHAR(50),
       is_delete TINYINT(1),
       create_dat DATETIME,
      update_dat TIMESTAMP
       );',

    'CREATE TABLE Solde (
        id_solde INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        s_credit VARCHAR(50),
        s_data VARCHAR(50),
        s_sms VARCHAR(50),
        s_minute VARCHAR(50),
        date_dexpi DATE, 
        is_delete TINYINT(1),
        create_dat DATETIME,
        update_dat TIMESTAMP,
        id_carte_sim INT(6) UNSIGNED,
        CONSTRAINT fk_carte_sim
        FOREIGN KEY( id_carte_sim) 
        REFERENCES carte_sim( id_carte_sim) 
        ON DELETE CASCADE
         );',

    'CREATE TABLE Recharge (
        id_recharge INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        rcredit VARCHAR(50),
         rdata VARCHAR(50),
         rsms VARCHAR(50),
         rminute VARCHAR(50),
         date_dexpi DATE,
         is_delete TINYINT(1),
         create_dat DATETIME,
         update_dat TIMESTAMP,
         id_carte_sim INT(6) UNSIGNED,
        CONSTRAINT f_carte_sim
        FOREIGN KEY( id_carte_sim) 
        REFERENCES carte_sim( id_carte_sim) 
        ON DELETE CASCADE
         );',

    'CREATE TABLE User (
      id_user INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
      email  VARCHAR(50),
      passwords VARCHAR (50),
      type_user TINYINT (1) DEFAULT 1 NOT NULL,
      is_delete TINYINT(1),
      create_dat DATETIME,
      update_dat TIMESTAMP
    );'




  ];

  foreach ($sql1 as $sql2) {
    $conn->exec($sql2);
  }
  echo "Tables created successfully";
} catch (PDOException $e) {
  echo $sql2 . "<br>" . $e->getMessage();
}

$conn = null;
