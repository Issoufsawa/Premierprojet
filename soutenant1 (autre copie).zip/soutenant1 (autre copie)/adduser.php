<?php
 require_once "Connect.php";
 require_once "templeteadmin.php";

 ?>




<head>
    
    <title>AUTHENTIFICATION</title>
</head>








<div id="page-wrapper" style="min-height: 292px;">




    <div class="row">
        <div class="col-lg-12 col-md-12">
            <h3 align="center" class=" bg-success titre-contact"> AJOUTER UN NOUVEL UTILISATEUR </h3>

            <div class="panel panel-primary">
                <form class="form-horizontal" data-toggle="validator" role="form" method="POST" action="">
                    <p></p>
                    <div class="row">
                        <div class="col-xs-12">

                            <!--<form class="form-horizontal" role="form">-->
                           
                           
                            <div class="form-group">
                                
                                <label class=" col-sm-4 control-label">EMAIL :</label>
                                <div class="col-sm-2">
                              
                                <input type="email" class="form-control" name="email" id="email" placeholder="email" autocomplete="off" required>
                                </div>
                            </div>

                            <div class="form-group">
                                <label class=" col-sm-4 control-label"> MOT DE PASSE :</label>
                                <div class="col-sm-2">
                               
                                    <input type="password" class="form-control" name="passwords" id="passwords"  placeholder ="mot de pass" autocomplete ="off" required>
                                </div>
                            </div>
                            <div class="form-group">

                                <div class=" col-sm-4 control-label d-flex justify-content-center  "><br><br>
                                    <button type="submit" class="btn btn-primary" name="submit">ENREGISTRER </button>
                                    <button type="reset" class="btn btn-default">Annuler </button><br>
                                </div>








                            </div>
                            <!--col-xs-12 -->

                        </div>
                        <!--row -->

                </form> <!--  /form>-->



            </div>

        </div>

</html>

<?php


$sql = null;
$sql1 = null;

if (isset($_POST['submit'])) {

    //On verfie que les champs ne sont pas vide et que les données saisies existent
    if (isset($_POST['email']) && !empty($_POST['email']) && $_POST['passwords']  && !empty($_POST['passwords'])) {
        //On recupère ce qui a ete saisie dans le formulaire
        $email = ($_POST['email']);
        
        //on verfie si l'email ou l'identifiant existe
        $sql = $db->prepare("SELECT email FROM User WHERE email='$email'");
        $sql->execute();
        $result = $sql->rowCount();
        
        if ($result) {
            
            echo  " l'email existe déja autre email svp <br> ";
        } else {
            
            $passwords = $_POST['passwords'];
            $password = hash('sha256', $passwords);
            $sql1 = " INSERT INTO User (email, passwords) 
                    VALUES ('$email', '$password') ";
            
            // utilise exec() car aucun résultat n'est renvoyé
            $db->exec($sql1);
            //je recupère l'identifiant et je l'ajoute dans le champ de l'id du token ainsi que le token generé
           
            echo "Nouveau enregistrement crée avec success $password <br> ";
        }
    }
}
?>